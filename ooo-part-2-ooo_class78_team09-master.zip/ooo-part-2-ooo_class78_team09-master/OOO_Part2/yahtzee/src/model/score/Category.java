package model.score;
import java.util.List;

import model.board.*;
public interface Category {
	public int getPoints(List<Dice> dicessc);
}
