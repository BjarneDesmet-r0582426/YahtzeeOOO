package controller;

public interface endGameObservable {

	void notifyText(String name, int score);
}
