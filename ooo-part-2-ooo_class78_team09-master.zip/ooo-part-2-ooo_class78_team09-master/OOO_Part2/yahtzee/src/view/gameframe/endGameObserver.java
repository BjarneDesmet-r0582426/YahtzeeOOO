package view.gameframe;

public interface endGameObserver {
	
	public void updateEndGame(String naam, int text);
}
